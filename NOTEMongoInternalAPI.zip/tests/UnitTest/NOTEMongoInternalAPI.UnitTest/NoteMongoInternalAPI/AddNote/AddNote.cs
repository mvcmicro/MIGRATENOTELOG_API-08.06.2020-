﻿using System;
using System.Collections.Generic;
using Xunit;
using NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.TestData;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.AddNote
{
    public class AddNote : InitMongo
    {
        [Theory]
        [ClassData(typeof(Theory_TrueCase_AddNote_List))]
        public void Insert_LogNote_SuccessCase(List<NoteModel> resource) {
            _context.LoadDataNoteMongoDb();
            var service = new NoteService(_context);
            var result = service.AddNote(resource);
            Assert.True(result.Exception == null);
            _runner.Dispose();
        }

        [Theory]
        [ClassData(typeof(Theory_FalseCase_AddNote_List))]
        public void Insert_LogNote_FalseCase_Return_Exception(List<NoteModel> resource) {

            _context.LoadDataNoteMongoDb();
            var service = new NoteService(_context);
            Assert.ThrowsAsync<Exception>(() => service.AddNote(resource));
            _runner.Dispose();
        }

    }
}

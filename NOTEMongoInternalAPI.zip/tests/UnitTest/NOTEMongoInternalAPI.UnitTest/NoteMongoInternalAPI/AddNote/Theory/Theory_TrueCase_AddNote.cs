﻿using System;
using System.Collections.Generic;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using Xunit;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.AddNote
{
    class Theory_TrueCase_AddNote : TheoryData<NoteModel>
    {
        public Theory_TrueCase_AddNote() {
            Add(
                new NoteModel
                {
                    idNote = 1000006,
                    csnNo = "00000006",
                    contractNo = "c1000005",
                    noteDate = Convert.ToDateTime("2021-08-12T15:00:00"),
                    //noteTime = Convert.ToDateTime("2020-08-12T15:00:00"),
                    actionCode = "CF3",
                    personCode = "PC000005",
                    resultCode = "CR03",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-12T15:00:00"),
                    //ppTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-12T15:00:00"),
                    //pdTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-12T15:00:00"),
                    //recallTime = Convert.ToDateTime("2021-09-12T15:00:00"),
                    ppAmt = Convert.ToDouble(500.5231),
                    alreadyPaidAmt = Convert.ToDouble(55555.2536889),
                    ppChannel = "PP0295",
                    callCenter = "CC-CS09",
                    telType = "TT09",
                    telNo = "+66896312345",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    noteFlag = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2021-09-13T15:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-15T15:00:00"),
                    updateBy = "IT USER"
                }
                );
        }
    }

    class Theory_TrueCase_AddNote_List : TheoryData<List<NoteModel>> 
    {
        public Theory_TrueCase_AddNote_List()
        {
            Add(
                new List<NoteModel>() {
                    new NoteModel
                    {
                        idNote = 1000007,
                        csnNo = "00000007",
                        contractNo = "c1000006",
                        noteDate = Convert.ToDateTime("2021-08-12T15:00:00"),
                        //noteTime = Convert.ToDateTime("2020-08-12T15:00:00"),
                        actionCode = "CF4",
                        personCode = "PC000006",
                        resultCode = "CR04",
                        noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                        ppDate = Convert.ToDateTime("2019-08-12T15:00:00"),
                        //ppTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                        pdDate = Convert.ToDateTime("2020-08-12T15:00:00"),
                        //pdTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                        recallDate = Convert.ToDateTime("2021-05-12T15:00:00"),
                        //recallTime = Convert.ToDateTime("2021-09-12T15:00:00"),
                        ppAmt = Convert.ToDouble(500.5231),
                        alreadyPaidAmt = Convert.ToDouble(55555.2536889),
                        ppChannel = "PP0296",
                        callCenter = "CC-CS09",
                        telType = "TT09",
                        telNo = "+66896312345",
                        callType = "CT8595",
                        contactTo = "คำอธิบาย",
                        systemBy = "CSSCREEN",
                        noteFlag = "1",
                        recordStatus = "1",
                        createDate = Convert.ToDateTime("2021-09-13T15:00:00"),
                        createBy = "IT USER",
                        updateDate = Convert.ToDateTime("2021-09-15T15:00:00"),
                        updateBy = "IT USER"

                    },
                    new NoteModel
                    {
                        idNote = 1000008,
                        csnNo = "00000008",
                        contractNo = "c1000007",
                        noteDate = Convert.ToDateTime("2021-08-12T15:00:00"),
                        //noteTime = Convert.ToDateTime("2020-08-12T15:00:00"),
                        actionCode = "CF5",
                        personCode = "PC000007",
                        resultCode = "CR05",
                        noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                        ppDate = Convert.ToDateTime("2019-08-12T15:00:00"),
                        //ppTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                        pdDate = Convert.ToDateTime("2020-08-12T15:00:00"),
                        //pdTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                        recallDate = Convert.ToDateTime("2021-05-12T15:00:00"),
                        //recallTime = Convert.ToDateTime("2021-09-12T15:00:00"),
                        ppAmt = Convert.ToDouble(500.5231),
                        alreadyPaidAmt = Convert.ToDouble(55555.2536889),
                        ppChannel = "PP0297",
                        callCenter = "CC-CS09",
                        telType = "TT09",
                        telNo = "+66896312345",
                        callType = "CT8595",
                        contactTo = "คำอธิบาย",
                        systemBy = "CSSCREEN",
                        noteFlag = "1",
                        recordStatus = "1",
                        createDate = Convert.ToDateTime("2021-09-13T15:00:00"),
                        createBy = "IT USER",
                        updateDate = Convert.ToDateTime("2021-09-15T15:00:00"),
                        updateBy = "IT USER"
                    }
                }
                );

        }
    }
}

﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using System.Collections.Generic;
using Xunit;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.AddNote
{
    class Theory_FalseCase_AddNote : TheoryData<NoteModel>
    {
        public Theory_FalseCase_AddNote() {
            Add(null);
        }
    }

    class Theory_FalseCase_AddNote_List : TheoryData<List<NoteModel>>
    {
        public Theory_FalseCase_AddNote_List()
        {
            Add(null);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using Xunit;
using System.Linq;
using NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.TestData;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.GetNote
{
    public class GetNoteFilter : InitMongo
    {
        [Theory]
        [ClassData(typeof(Theory_TrueCase_GetNote))]
        public void GetSearchNote_Success_Return_TS_TimeLineModel(Resource resource)
        {
            _context.LoadDataNoteMongoDb();
            var service = new NoteService(_context);
            List<NoteModel> data = service.GetFilterNote(resource).Result;
            Assert.True(data.IsEmpty() || !data.IsEmpty()); // << ตรงนี้ มี หรือ ไม่มี ก็ได้
            _runner.Dispose();
        }

        [Theory]
        [ClassData(typeof(Theory_FalseCase_GetNote))]
        public void GetSearchNote_False_Return_Null(Resource resource)
        {
            _context.LoadDataNoteMongoDb();
            var service = new NoteService(_context);
            Assert.ThrowsAsync<Exception>(() => service.GetFilterNote(resource));
            _runner.Dispose();
        }

    }
}

﻿using Xunit;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.GetNote
{
    class Theory_FalseCase_GetNote : TheoryData<Resource>
    {
        public Theory_FalseCase_GetNote()
        {
            Add(null);
        }
    }
}

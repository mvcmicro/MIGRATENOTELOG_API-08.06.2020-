﻿using System.Collections.Generic;
using Xunit;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.GetNote
{
    class Theory_TrueCase_GetNote : TheoryData<Resource>
    {
        public Theory_TrueCase_GetNote()
        {

            Add(new Resource
            {
                actionCode = new List<string>{
                    "CF1","CF2"
                },
                resultCode = new List<string>{
                    "CR01","CR02"
                }
            });

            //--------------------------------------------------------------//

            Add(new Resource
            {
                actionCode = new List<string>{
                    "CF1","CF2"
                },
                resultCode = new List<string>{
                    "CR01","CR02"
                },
                columnName = "csnNo",
                txtValue = "00000001"
            });

            Add(new Resource
            {
                actionCode = new List<string>{
                    "CF1","CF2" ,""
                },
                resultCode = new List<string>{
                    "CR2","CR3" ,""
                },
                txtValue = "00000001"
            });
            ////----------------------------------------------------------------------//
            Add(new Resource
            {
                actionCode = new List<string>{
                    "CF1","CF2"
                }
            });

            Add(new Resource
            {
                resultCode = new List<string>{
                    "CR01","CR02"
                }
            });
            ////-----------------------------------------------------------------------//
            Add(new Resource
            {
                columnName = "csnNo",
                txtValue = "00000001"
            });
            Add(new Resource
            {
                txtValue = "00000001"
            });
            ////---------------------------------------------------------------------//
            Add(new Resource
            {
                columnName = "noteDate",
                txtValue = "2020-01-01"
            });
            Add(new Resource
            {
                txtValue = "2020-01-01"
            });

        }
    }
}

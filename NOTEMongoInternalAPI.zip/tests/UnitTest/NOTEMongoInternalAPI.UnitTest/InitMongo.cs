﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess.Interfaces;
using Mongo2Go;
using MongoDB.Driver;

namespace NOTEMongoInternalAPI.UnitTest
{
    public class InitMongo
    {
        public MongoDbRunner _runner;
        public INoteDbContext _context;
        private readonly IMongoClient _client;
        private readonly string _db = "ExNote";

        public InitMongo()
        {
            _runner = MongoDbRunner.Start();
            _client = new MongoClient(_runner.ConnectionString);
            _context = new NoteDbContext(_client,_db);
        }
    }
}

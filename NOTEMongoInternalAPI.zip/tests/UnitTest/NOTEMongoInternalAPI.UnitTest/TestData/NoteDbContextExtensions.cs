﻿using System.Collections.Generic;
using System;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess.Interfaces;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;

namespace NOTEMongoInternalAPI.UnitTest.NOTEMongoInternalAPI.TestData
{
    public static class NoteDbContextExtensions
    {
        public static void LoadDataNoteMongoDb(this INoteDbContext _context)
        {
            _context.LogNote.InsertMany(new List<NoteModel>()
            {
                new NoteModel
                {
                    idNote = 1000001,
                    csnNo = "00000001",
                    contractNo = "c1000005",
                    noteDate = Convert.ToDateTime("2020-01-01T00:00:00"),
                    //noteTime = Convert.ToDateTime("2020-08-12T15:00:00"),
                    actionCode = "CF1",
                    personCode = "ออก",
                    resultCode = "CR01",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-12T15:00:00"),
                    //ppTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-12T15:00:00"),
                    //pdTime = Convert.ToDateTime("2021-08-12T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-12T15:00:00"),
                    //ecallTime = Convert.ToDateTime("2021-09-12T15:00:00"),
                    ppAmt = Convert.ToDouble(500.5231),
                    alreadyPaidAmt = Convert.ToDouble(55555.2536889),
                    ppChannel = "PP0296",
                    callCenter = "CC-CS09",
                    telType = "TT09",
                    telNo = "+66896312345",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    noteFlag = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2021-09-13T15:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-15T15:00:00"),
                    updateBy = "IT USER"
                }
                ,
                new NoteModel
                {
                    idNote = 1000002,
                    csnNo = "00000002",
                    contractNo = "c1000123",
                    noteDate = Convert.ToDateTime("2021-08-12T15:00:00"),
                    //noteTime = Convert.ToDateTime("2020-08-12T15:00:00"),
                    actionCode = "CF2",
                    personCode = "PC000025",
                    resultCode = "CR02",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2011-08-12T15:00:00"),
                    //ppTime = Convert.ToDateTime("2012-08-12T15:00:00"),
                    pdDate = Convert.ToDateTime("2011-07-16T15:00:00"),
                    //pdTime = Convert.ToDateTime("2012-07-16T15:00:00"),
                    recallDate = Convert.ToDateTime("2019-05-18T15:00:00"),
                    //recallTime = Convert.ToDateTime("2019-09-18T15:00:00"),
                    ppAmt = Convert.ToDouble(5001.5231),
                    alreadyPaidAmt = Convert.ToDouble(10555.2536889),
                    ppChannel = "PP0290",
                    callCenter = "CC-CS04",
                    telType = "TT08",
                    telNo = "+66896312379",
                    callType = "CT8500",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    noteFlag = "0",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2021-12-13T15:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-12-15T15:00:00"),
                    updateBy = "IT USER"
                }
            });
        }
    }
}

﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace razorTes.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;
        public string assemName { set; get; }
        public string assemVer { set; get; }
        public string ipAddr { set; get; }
        public string dateModified { set; get; }
        public string dbNameEnv { set; get; }
        public string dbName { set; get; }
        public string dbNameRLEnv { set; get; }
        public string dbNameRL { set; get; }
        public string envMssql
        {
            get
            {
                return String.Format("Name: {0} | Value: {1}", dbNameEnv, dbName);
            }
        }
        public string envMssqlRL
        {
            get
            {
                return String.Format("Name: {0} | Value: {1}", dbNameRLEnv, dbNameRL);
            }
        }

        public string coreEnv { set; get; }

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            var assemblyAll = Assembly.GetEntryAssembly().GetName();
            var assemblyExe = Assembly.GetExecutingAssembly();
            assemName = assemblyAll.Name;
            assemVer = assemblyAll.Version.ToString();
            ipAddr = GetIPAddress();

            dbNameEnv = _configuration["EnvironmentVariables:ENV_MSSQLDB_NAME"];
            if (String.IsNullOrEmpty(dbNameEnv) == false)
            {
                dbName = Environment.GetEnvironmentVariable(dbNameEnv);
            }

            dbNameRLEnv = _configuration["EnvironmentVariables:ENV_MSSQLRLDB_NAME"];
            if (String.IsNullOrEmpty(dbNameRLEnv) == false)
            {
                dbNameRL = Environment.GetEnvironmentVariable(dbNameRLEnv);
            }

            coreEnv = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            FileInfo file = new FileInfo(assemblyExe.Location);
            dateModified = file.LastWriteTime.ToString("dd/MM/yyyy : HH:mm:ss");
        }

        private string GetIPAddress()
        {
            try
            {
                IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
                string HostName_ = Dns.GetHostEntry(Dns.GetHostName()).HostName;
                return HostName_;
            }
            catch {
                return "";
            }
        }
    }
}

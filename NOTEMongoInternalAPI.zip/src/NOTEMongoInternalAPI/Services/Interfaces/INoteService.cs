﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services.Interfaces
{
    public interface INoteService
    {
        Task<NoteModel> GetAllNoteFirstRow();
        Task<List<NoteModel>> GetAllNote();
        //Task<List<NoteModel>> GetFilterNote(Resource resource);
        Task<List<NoteModel>> SearchNote(Resource reqData);
        Task AddNote(List<NoteModel> models);
        Task RemoveNote(int idNote);
    }

}

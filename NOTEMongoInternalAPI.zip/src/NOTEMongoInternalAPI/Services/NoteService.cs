﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess.Interfaces;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services.Interfaces;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services
{
    public class NoteService : INoteService
    {
        private readonly INoteDbContext _context;

        public NoteService(INoteDbContext context)
        {
            _context = context;
        }

        public async Task<NoteModel> GetAllNoteFirstRow()
        {
            try
            {
                return await _context.LogNote.Find(x => x.actionCode == "xxxxxxxxx").FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<NoteModel>> GetAllNote()
        {
            try
            {
                return await _context.LogNote.Find(_ => true).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region GetFilterNote
        //public async Task<List<NoteModel>> GetFilterNote(Resource resource)
        //{
        //    try
        //    {
        //        var model = new NoteModel();
        //        Type type = model.GetType();
        //        PropertyInfo[] props = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
        //        var _filter = Builders<NoteModel>.Filter;
        //        var _filters = new List<FilterDefinition<NoteModel>>();
        //        BsonDocument bson = new BsonDocument();
        //        FilterDefinition<NoteModel> cmdSearch = null;

        //        if (!resource.actionCode.IsEmpty() && !resource.resultCode.IsEmpty()) // btn Caseful and Telesale
        //        {
        //            if (!string.IsNullOrEmpty(resource.columnName) && !string.IsNullOrEmpty(resource.txtValue))
        //            {
        //                cmdSearch = _filter.And(
        //                    _filter.In(f => f.actionCode, resource.actionCode),
        //                    _filter.In(f => f.resultCode, resource.resultCode),
        //                    _filter.Regex(resource.columnName, resource.txtValue)
        //                );
        //            }
        //            else if (string.IsNullOrEmpty(resource.columnName) && !string.IsNullOrEmpty(resource.txtValue))
        //            {
        //                #region old code
        //                //for (int i = 0; i < props.Length; i++)
        //                //{
        //                //    _filters.Add(_filter.Regex(props[i].Name, resource.txtValue));
        //                //}
        //                #endregion
        //                foreach (var value in props)
        //                {
        //                    _filters.Add(_filter.Regex(value.Name, resource.txtValue));
        //                }

        //                cmdSearch = _filter.And(
        //                   _filter.In(f => f.actionCode, resource.actionCode),
        //                   _filter.In(f => f.resultCode, resource.resultCode),
        //                   _filter.Or(_filters)
        //                );
        //            }
        //            else
        //            {
        //                cmdSearch = _filter.And(
        //                    _filter.In(f => f.actionCode, resource.actionCode),
        //                    _filter.In(f => f.resultCode, resource.resultCode)
        //                );
        //            }
        //        }
        //        else if (!resource.actionCode.IsEmpty() && resource.resultCode.IsEmpty()) // select actionCode only
        //        {
        //            cmdSearch = _filter.And(
        //                            _filter.In(f => f.actionCode, resource.actionCode)
        //                        );
        //        }
        //        else if (!resource.resultCode.IsEmpty() && resource.actionCode.IsEmpty()) // select resultCode only
        //        {
        //            cmdSearch = _filter.And(
        //                            _filter.In(f => f.resultCode, resource.resultCode)
        //                        );
        //        }
        //        else
        //        {
        //            if (!string.IsNullOrEmpty(resource.columnName) && !string.IsNullOrEmpty(resource.txtValue))
        //            {
        //                cmdSearch = '
        //            }
        //            else if (string.IsNullOrEmpty(resource.columnName) && !string.IsNullOrEmpty(resource.txtValue))
        //            {
        //                #region old code
        //                //for (int i = 0; i < props.Length; i++)
        //                //{
        //                //    listRegex.Add($"/.*{resource.txtValue}.*/.test(this.{props[i].Name})");
        //                //}
        //                #endregion
        //                List<string> listRegex = new List<string>();
        //                foreach (var prop in props)
        //                {
        //                    listRegex.Add($"/.*{resource.txtValue}.*/.test(this.{prop.Name})");
        //                }
        //                bson.Add("$where", string.Join(" || ", listRegex));

        //                cmdSearch = _filter.Or(bson);
        //            }
        //            else if (!string.IsNullOrEmpty(resource.columnName) && resource.StartDateTime != null && resource.EndDateTime != null)
        //            {
        //                #region old code
        //                //if (DateTime.TryParseExact(resource.txtValue, "dd/MM/yyyy", null, DateTimeStyles.None, out DateTime dateConvert))
        //                //{
        //                //    DateTime StartDateTime = DateTime.ParseExact(dateConvert.ToString("yyyy-MM-dd"), "yyyy-MM-dd",
        //                //        CultureInfo.CreateSpecificCulture("en-US"));   // รับค่าจาก String txtValue >> format ปี/เดือน/วัน 
        //                //    cmdSearch = bson.Add(resource.columnName, new BsonDocument()
        //                //        .Add("$gte", new BsonDateTime(StartDateTime.AddHours(7)))
        //                //        .Add("$lte", new BsonDateTime(StartDateTime.AddHours(7)))
        //                //        );
        //                //}
        //                #endregion

        //                cmdSearch = bson.Add(resource.columnName, new BsonDocument()
        //                    .Add("$gte", new BsonDateTime(resource.StartDateTime.Value.AddHours(7)))
        //                    .Add("$lte", new BsonDateTime(resource.EndDateTime.Value.AddHours(7)))
        //                );
        //            }
        //            else
        //            {
        //                throw new Exception("Invalid date input"); // ไม่มีเงื่อนไขที่ถูกต้อง ส่ง exception ออกไป .
        //            }
        //        }

        //        return await _context.LogNote.Find(cmdSearch).Skip(resource.skipRows).Limit(0).ToListAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        #endregion

        public async Task<List<NoteModel>> SearchNote(Resource reqData)
        {
            try
            {
                var model = new NoteModel();
                Type type = model.GetType();
                PropertyInfo[] props = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                var _filter = Builders<NoteModel>.Filter;
                var _filters = new List<FilterDefinition<NoteModel>>();
                BsonDocument bson = new BsonDocument();
                FilterDefinition<NoteModel> cmdSearch = null;

                if (reqData != null)
                {
                    if (!string.IsNullOrEmpty(reqData.csnNo))
                    {
                        _filters.Add(_filter.And(_filter.Regex(f => f.csnNo, reqData.csnNo)));
                    }
                    if (!string.IsNullOrEmpty(reqData.contractNo))
                    {
                        _filters.Add(_filter.And(_filter.Regex(f => f.contractNo, reqData.contractNo)));
                    }
                    if (!reqData.actionCode.IsEmpty())
                    {
                        _filters.Add(_filter.And(_filter.In(f => f.actionCode, reqData.actionCode)));
                    }
                    if (!reqData.resultCode.IsEmpty())
                    {
                        _filters.Add(_filter.And(_filter.In(f => f.resultCode, reqData.resultCode)));
                    }
                    if (!reqData.personCode.IsEmpty())
                    {
                        _filters.Add(_filter.And(_filter.In(f => f.personCode, reqData.personCode)));
                    }
                    if (!string.IsNullOrEmpty(reqData.noteDescription))
                    {
                        _filters.Add(_filter.And(_filter.Regex(f => f.noteDescription, reqData.noteDescription)));
                    }
                    if (!string.IsNullOrEmpty(reqData.createBy))   //createBy แทนด้วย noteByName
                    {
                        //_filters.Add(_filter.And(_filter.Regex(f => f.createBy, reqData.createBy)));
                        //_filters.Add(_filter.And(_filter.Regex(_filter.Or(f => f.noteByName, reqData.createBy), _filter.Regex(f => f.noteBy, reqData.createBy))));
                        //_filters.Add(_filter.And(_filter.Or(_filter.Regex(f => f.noteByName, reqData.createBy), _filter.And(_filter.Or(_filter.Eq(f => f.noteByName, null), _filter.Eq(f => f.noteByName, string.Empty)), _filter.Regex(f => f.noteBy, reqData.createBy)))));


                        //_filters.Add(_filter.And(_filter.Or(bson.Add("noteByName", new BsonRegularExpression("^" + reqData.createBy + ".*$", "i")), _filter.And(_filter.Or(_filter.Eq(f => f.noteByName, null), _filter.Eq(f => f.noteByName, string.Empty)), bson.Add("noteBy", new BsonRegularExpression("^" + reqData.createBy + ".*$", "i"))))));

                        //bson.Add("csnNo", reqData.csnNo);
                        //bson.Add("noteByName", new BsonRegularExpression("^" + reqData.createBy + ".*$", "i"));

                        //List<string> listRegex = new List<string>();

                        //listRegex.Add($"/.*{reqData.csnNo}.*/.test(this.csnNo)");
                        //listRegex.Add($"/.*{reqData.createBy}.*/.test(this.noteByName)");
                        //bson.Add("$where", string.Join(" || ", listRegex));

                        //bson.Add($"/.*noteByName.*/.test(this.{reqData.csnNo})", "");
                        //$"/.*{resource.txtValue}.*/.test(this.{props[i].Name})"
                        //bson.Add("noteBy", new BsonRegularExpression("^.*" + reqData.createBy + ".*$", "i"))


                        bson.Add("$where", $"/.*{reqData.csnNo}.*/.test(this.csnNo)");
                        bson.Add("$where", $"/.*{reqData.createBy}.*/.test(this.noteByName)");


                        //_filters.Add(_filter.And(bson.Add("noteByName", new BsonRegularExpression("^.*" + reqData.createBy + ".*$", "i"))));

                        //_filters.Add(_filter.And(_filter.Or(_filter.Regex(f => f.noteByName, reqData.createBy), _filter.Regex(f => f.noteBy, reqData.createBy))));
                    }
                    if (!reqData.columnDate.IsEmpty() && reqData.startDate != null && reqData.endDate != null)
                    {
                        DateTime StartDateTime = DateTime.Parse(reqData.startDate.Value.ToString("yyyy-MM-dd 00:00:00"));
                        DateTime EndDateTime = DateTime.Parse(reqData.endDate.Value.ToString("yyyy-MM-dd 23:59:59"));

                        //foreach (var value in reqData.columnDate)
                        //{
                        //    _filters.Add(_filter.And(bson.Add(value, new BsonDocument()
                        //        .Add("$gte", new BsonDateTime(StartDateTime.AddHours(7)))
                        //        .Add("$lte", new BsonDateTime(EndDateTime.AddHours(7)))
                        //    )));
                        //}

                        foreach (var valueDate in reqData.columnDate)
                        {
                            _filters.Add(_filter.And(
                                _filter.Gte(valueDate, StartDateTime.AddHours(7)),
                                _filter.Lte(valueDate, EndDateTime.AddHours(7))
                            ));
                        }
                    }
                    if (reqData.specialFlag == 1)   //ถ้าเป็น 0 เข้าจากเมนู Special / ถ้าเป็น 1 มาจาก CS หรือ Call
                    {
                        //_filters.Add(bson.Add("noteDate", new BsonDocument()
                        //        .Add("$gte", new BsonDateTime(DateTime.Now.AddHours(7).AddYears(-1)))
                        //        .Add("$lte", new BsonDateTime(DateTime.Now.AddHours(7)))
                        //    ));

                        _filters.Add(_filter.And(
                                    _filter.Gte(f => f.noteDate, DateTime.Now.AddHours(7).AddYears(-1)),
                                    _filter.Lte(f => f.noteDate, DateTime.Now.AddHours(7))
                                ));
                    }

                    cmdSearch = _filter.And(bson);
                }
                else
                {
                    throw new Exception("Invalid not input!");
                }

                return await _context.LogNote.Find(cmdSearch).Skip(reqData.skipRows).Limit(0).ToListAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task AddNote(List<NoteModel> models)
        {
            try
            {
                await _context.LogNote.InsertManyAsync(models);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveNote(int idNote)
        {
            try
            {
                var result = await _context.LogNote.DeleteOneAsync(f => f.idNote == idNote);

                if (result.IsAcknowledged && result.DeletedCount == 0)
                {
                    throw new Exception($"Not found record for delete Note {idNote}.");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
#!/usr/bin/env bash

set -x

export "MiniCover=dotnet minicover"
export "PROJECTNAME=NOTEMongoInternalAPI"
export "THRESHOLD=80"

cd ../../tests/UnitTest/$PROJECTNAME.UnitTest
$MiniCover instrument --workdir ../../../ --sources "src/$PROJECTNAME/Services/**/*.cs" --assemblies "tests/UnitTest/$PROJECTNAME.UnitTest/bin/**/*.dll" --coverage-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.json" --hits-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage-hits.txt"
$MiniCover reset

dotnet test --no-build

$MiniCover uninstrument --workdir ../../../ --coverage-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.json"
$MiniCover htmlreport --workdir ../../../ --coverage-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.json" --output "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/report" --threshold $THRESHOLD
$MiniCover xmlreport --workdir ../../../ --coverage-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.json" --output "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.xml" --threshold $THRESHOLD
$MiniCover report --workdir ../../../ --coverage-file "tests/UnitTest/$PROJECTNAME.UnitTest/TestResults/coverage.json" --threshold $THRESHOLD

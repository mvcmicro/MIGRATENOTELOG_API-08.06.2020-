﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class HealthCheckController : ControllerBase
    {
        private readonly INoteService _noteService;
        public HealthCheckController(INoteService noteService)
        {
            this._noteService = noteService;
        }

        [HttpGet(Name = "APIHealthCheck")]
        public async Task<object> APIHealthCheck()
        {
            string message = "Connect NOTEMongoInternalAPI Success!";
            try
            {
                var data = await this._noteService.GetAllNoteFirstRow();
                return new { message = string.Format("{0}", message)};
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("{0} | Not connect to MongoDB because: {1}"
                    + message, ex.Message));
            }
        }
    }

    //public class CallForTest
    //{
    //    public asyncobject
    //}
}
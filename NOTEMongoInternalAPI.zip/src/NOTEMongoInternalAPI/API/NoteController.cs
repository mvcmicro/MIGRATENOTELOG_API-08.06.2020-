﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Services.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class NoteController : ControllerBase
    {
        private readonly IServiceProvider _service;
        public NoteController(IServiceProvider service)
        {
            _service = service;
        }

        //[HttpGet("All", Name = "GetAllNote")]
        //public async Task<List<NoteModel>> GetAllNote()
        //{
        //    var Service = _service.GetService<INoteService>();
        //    return await Service.GetAllNote();
        //}

        //[HttpPost("GetFilterNote", Name = "CareandTel")]
        //public async Task<List<NoteModel>> GetFilterNote([FromBody] Resource resource)
        //{
        //    var Service = _service.GetService<INoteService>();
        //    return await Service.GetFilterNote(resource);
        //}

        [HttpPost("SearchNote", Name = "SearchNote")]
        public async Task<List<NoteModel>> SearchNote([FromBody] Resource resource)
        {
            var Service = _service.GetService<INoteService>();
            return await Service.SearchNote(resource);
        }

        [HttpPost("InsertNote",Name = "InsertNote")]
        public async Task InsertNote([FromBody]List<NoteModel> data)
        {
            var Service = _service.GetService<INoteService>();
            await Service.AddNote(data);
        }

        [HttpDelete("{idNote}", Name = "DeleteNote")]
        public async Task DeleteNote(int idNote)
        {
            var brandService = _service.GetService<INoteService>();
            await brandService.RemoveNote(idNote);
        }
    }
}
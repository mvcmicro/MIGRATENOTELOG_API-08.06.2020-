﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models
{
    public class NoteModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public Int64 idNote { get; set; }
        public string csnNo { get; set; }
        public string contractNo { get; set; }
        public DateTime? noteDate { get; set; }
        //public DateTime? noteTime { get; set; }
        public string actionCode { get; set; }
        public string personCode { get; set; }
        public string resultCode { get; set; }
        public string noteDescription { get; set; }
        public DateTime? ppDate { get; set; }
        //public DateTime? ppTime { get; set; }
        public DateTime? pdDate { get; set; }
        //public DateTime? pdTime { get; set; }
        public DateTime? recallDate { get; set; }
        //public DateTime? recallTime { get; set; }
        public double ppAmt { get; set; }
        public double alreadyPaidAmt { get; set; }
        public string ppChannel { get; set; }
        public string callCenter { get; set; }
        public string telType { get; set; }
        public string telNo { get; set; }
        public string callType { get; set; }
        public string contactTo { get; set; }
        public string noteRemark { get; set; }
        public string systemBy { get; set; }
        public string noteFlag { get; set; }
        public string recordStatus { get; set; }
        public string noteBy { get; set; }
        public string noteByName { get; set; }
        public DateTime? createDate { get; set; }
        public string createBy { get; set; }
        public DateTime? updateDate { get; set; }
        public string updateBy { get; set; }
    }

    public class Resource
    {
        //public List<string> actionCode { get; set; }
        //public List<string> resultCode { get; set; }
        //public List<string> personCode { get; set; }
        //public string columnName { get; set; }
        //public string txtValue { get; set; }


        public string csnNo { get; set; }
        public string contractNo { get; set; }
        public List<string> actionCode { get; set; }
        public List<string> resultCode { get; set; }
        public List<string> personCode { get; set; }
        public List<string> columnDate { set; get; }
        public DateTime? startDate { get; set; }
        public DateTime? endDate { get; set; }
        public string noteDescription { get; set; }
        public string createBy { get; set; }
        public int skipRows { get; set; }
        public int specialFlag { get; set; }
    }
}

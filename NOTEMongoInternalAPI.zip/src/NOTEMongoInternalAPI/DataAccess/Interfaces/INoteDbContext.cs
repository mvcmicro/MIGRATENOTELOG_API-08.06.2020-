﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess.Interfaces
{
    public interface INoteDbContext
    {
        IMongoCollection<NoteModel> LogNote { get; }
    }
}

﻿using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess.Interfaces;
using Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Easybuy.WebApplication.MigrateNote.NOTEMongoInternalAPI.DataAccess
{
    public class NoteDbContext : INoteDbContext
    {
        private readonly IMongoDatabase _db;
        public NoteDbContext(IMongoClient client, string dbName)
        {
            _db = client.GetDatabase(dbName);
        }
        public IMongoCollection<NoteModel> LogNote => _db.GetCollection<NoteModel>("TS_TimeLine");
    }
}
